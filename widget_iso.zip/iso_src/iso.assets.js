(function (window, document) {
  'use strict';

  function loadCss(id, href) {
    if (document.getElementById(id)) return;
    var link = document.createElement('link');
    link.id = id;
    link.rel = 'stylesheet';
    link.href = href;
    document.head.appendChild(link);
  }

  function applyThemeVars() {
    if (document.getElementById('user_iso_css')) return;
    var theme = (window.jeedom && window.jeedom.theme) ? window.jeedom.theme : {};
    var stepWidth = Math.max(84, theme['widget::step::width'] || 40);
    var stepHeight = Math.max(20, theme['widget::step::height'] || 20);
    var margin = theme['widget::margin'] || 4;

    var style = document.createElement('style');
    style.id = 'user_iso_css';
    style.textContent = ':root{' +
      '--widget-step-width:' + stepWidth + 'px;' +
      '--widget-step-height:' + stepHeight + 'px;' +
      '--widget-margin:' + margin + 'px;' +
      '}';
    document.head.appendChild(style);
  }

  function isoEnsureAssets() {
    loadCss('iso_css', 'data/customTemplates/dashboard/iso_src/cmd.iso.css?v=20260726b');
    loadCss('custom_iso_css', 'data/customTemplates/dashboard/iso_src/custom.iso.css?v=20260614e');
    applyThemeVars();
  }

  window.isoEnsureAssets = isoEnsureAssets;
})(window, document);
