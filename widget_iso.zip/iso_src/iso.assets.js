(function (window, document) {
  'use strict';

  function loadCss(id, href) {
    if (document.getElementById(id)) return;
    var link = document.createElement('link');
    link.id = id;
    link.rel = 'stylesheet';
    link.href = href;
    document.head.appendChild(link);
  }

  function applyThemeVars() {
    if (document.getElementById('user_iso_css')) return;
    var theme = (window.jeedom && window.jeedom.theme) ? window.jeedom.theme : {};
    var stepWidth = Math.max(84, theme['widget::step::width'] || 40);
    var stepHeight = Math.max(20, theme['widget::step::height'] || 20);
    var margin = theme['widget::margin'] || 4;

    var style = document.createElement('style');
    style.id = 'user_iso_css';
    style.textContent = ':root{' +
      '--widget-step-width:' + stepWidth + 'px;' +
      '--widget-step-height:' + stepHeight + 'px;' +
      '--widget-margin:' + margin + 'px;' +
      '}';
    document.head.appendChild(style);
  }

  /* ---- Option grille (masonry), cf. section 8 de cmd.iso.css ----
     Activée seulement si l'équipement porte --iso-masonry: 1 (custom.iso.css). */
  var MASONRY_MQ = '(min-width: 769px)';
  var masonryTracked = new Set();
  var masonryTimer = null;

  function masonryWanted(eq) {
    return getComputedStyle(eq).getPropertyValue('--iso-masonry').trim() === '1';
  }

  // Pas vertical Jeedom (widget::step::height, injecté sur :root par applyThemeVars).
  function rowStep() {
    return parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--widget-step-height')) || 30;
  }

  // Hauteur calée sur la trame : n pas, marges comprises (LINE 24 + 2 x 3 = 30 = 1 pas).
  // La hauteur naturelle est relue sans le min-height posé au calcul précédent.
  function setSpan(el) {
    el.style.removeProperty('--iso-minh');
    var cs = getComputedStyle(el);
    var margins = (parseFloat(cs.marginTop) || 0) + (parseFloat(cs.marginBottom) || 0);
    var outer = el.getBoundingClientRect().height + margins;
    if (outer < 1) { el.style.setProperty('--iso-span', 1); return; } // .break : 1px
    var step = rowStep();
    var n = Math.max(1, Math.ceil((outer - 0.5) / step));
    el.style.setProperty('--iso-span', n * step);
    el.style.setProperty('--iso-minh', (n * step - margins) + 'px');
  }

  // Moitié d'une LINE marges comprises : ((step - margeLR) * nbStep + 2 * margeLR) / 2
  function columnWidth(cmds) {
    var w = cmds.querySelector(':scope > .widget-iso');
    if (!w) return 0;
    var cs = getComputedStyle(w);
    var step = parseFloat(cs.getPropertyValue('--step-width'));
    var m = parseFloat(cs.getPropertyValue('--margin-LR'));
    var n = parseFloat(cs.getPropertyValue('--nbStep'));
    if (!(step > 0) || !(n > 0) || isNaN(m)) return 0;
    return ((step - m) * n + 2 * m) / 2;
  }

  // Retire la grille (retour au flex) sans cesser de surveiller la largeur.
  function masonryDisable(cmds) {
    var st = cmds._isoMasonry;
    if (st) { st.items.disconnect(); st.content.disconnect(); }
    if (!cmds.classList.contains('iso-masonry-on')) return;
    cmds.classList.remove('iso-masonry-on');
    cmds.style.removeProperty('--iso-colw');
    Array.prototype.forEach.call(cmds.children, function (el) { el.style.removeProperty('--iso-span'); el.style.removeProperty('--iso-minh'); });
  }

  // Option retirée ou tuile supprimée du DOM : plus aucun observateur.
  function masonryRelease(cmds) {
    masonryDisable(cmds);
    var st = cmds._isoMasonry;
    if (st) st.box.disconnect();
    cmds._isoMasonry = null;
    masonryTracked.delete(cmds);
  }

  // Applique (ou retire) la grille selon l'option, la largeur et la disposition.
  function masonryApply(cmds) {
    var eq = cmds.closest('.eqLogic-widget');
    if (!eq || !eq.classList.contains('hasIsocmds') || !masonryWanted(eq)) { masonryRelease(cmds); return; }

    // Option voulue : la largeur du conteneur reste surveillée même en flex
    // (tuile élargie en mode édition => la grille revient).
    var st = cmds._isoMasonry;
    if (!st) {
      st = {
        items: new ResizeObserver(function (entries) {
          if (!cmds.classList.contains('iso-masonry-on')) return;
          var done = new Set();
          entries.forEach(function (e) {
            var w = e.target.parentElement === cmds ? e.target : e.target.parentElement;
            if (w && w.parentElement === cmds && !done.has(w)) { done.add(w); setSpan(w); }
          });
        }),
        // Contenu modifié (valeur, liste, dialogue) : la hauteur naturelle est relue,
        // y compris quand elle diminue sous le min-height posé.
        content: new MutationObserver(function (records) {
          if (!cmds.classList.contains('iso-masonry-on')) return;
          var done = new Set();
          records.forEach(function (r) {
            var w = r.target.nodeType === 1 ? r.target : r.target.parentElement;
            while (w && w.parentElement !== cmds) w = w.parentElement;
            if (w && !done.has(w)) { done.add(w); setSpan(w); }
          });
        }),
        box: new ResizeObserver(function () {
          if (cmds.clientWidth !== st.width) { st.width = cmds.clientWidth; masonrySchedule(); }
        }),
        width: cmds.clientWidth
      };
      cmds._isoMasonry = st;
      masonryTracked.add(cmds);
      st.box.observe(cmds);
    }

    var colw = columnWidth(cmds);
    var ok = window.matchMedia(MASONRY_MQ).matches &&
      !cmds.querySelector('table') && colw > 0 &&
      cmds.clientWidth >= colw * 4; // au moins deux LINE côte à côte, sinon rien à gagner
    if (!ok) { masonryDisable(cmds); return; }

    cmds.style.setProperty('--iso-colw', colw + 'px');
    cmds.classList.add('iso-masonry-on');
    Array.prototype.forEach.call(cmds.children, setSpan);
    st.items.disconnect();
    st.content.disconnect();
    st.content.observe(cmds, { childList: true, characterData: true, subtree: true });
    // Le widget (agrandissement) et ses enfants directs (contenu qui rétrécit sous le min-height).
    Array.prototype.forEach.call(cmds.children, function (el) {
      st.items.observe(el);
      Array.prototype.forEach.call(el.children, function (c) { if (c.tagName !== 'SCRIPT' && c.tagName !== 'TEMPLATE') st.items.observe(c); });
    });
  }

  function masonryScan() {
    masonryTimer = null;
    masonryTracked.forEach(function (cmds) { if (!cmds.isConnected) masonryRelease(cmds); });
    document.querySelectorAll('.eqLogic-widget.hasIsocmds .cmds-iso').forEach(function (cmds) {
      if (cmds._isoMasonry || masonryWanted(cmds.closest('.eqLogic-widget'))) masonryApply(cmds);
    });
  }

  function masonrySchedule() {
    if (masonryTimer) return;
    masonryTimer = setTimeout(function () { window.requestAnimationFrame(masonryScan); }, 60);
  }

  if (typeof ResizeObserver === 'function' && window.matchMedia) {
    window.addEventListener('resize', masonrySchedule);
    var mq = window.matchMedia(MASONRY_MQ);
    if (mq.addEventListener) mq.addEventListener('change', masonrySchedule);
  } else {
    masonrySchedule = function () {}; // navigateur trop ancien : flex inchangé
  }

  function isoEnsureAssets() {
    loadCss('iso_css', 'data/customTemplates/dashboard/iso_src/cmd.iso.css?v=20261114d');
    loadCss('custom_iso_css', 'data/customTemplates/dashboard/iso_src/custom.iso.css?v=20261114b');
    applyThemeVars();
    masonrySchedule(); // chaque widget iso rendu relance un scan (regroupé)
  }

  window.isoEnsureAssets = isoEnsureAssets;
})(window, document);
