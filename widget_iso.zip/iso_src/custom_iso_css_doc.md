# Personnalisation des widgets ISO — `custom.iso.css`

Ce fichier est **le seul endroit recommandé** pour personnaliser l'apparence des widgets ISO.  
Il est chargé automatiquement après `cmd.iso.css` (la feuille principale) et ses règles prennent donc la priorité.

> ⚠️ Ne jamais modifier `cmd.iso.css` directement — vos changements seraient écrasés lors d'une mise à jour.

---

## 1. Disposition des widgets dans une tuile

Deux cas, selon la disposition choisie dans Jeedom (équipement → Configuration avancée → Disposition) :

- **Par défaut** : les widgets ISO se suivent ligne par ligne (flexbox `wrap`, centré) dans le conteneur
  `.eqLogic-widget.hasIsocmds .cmds-iso`. Il n'y a **pas de grille** ni de colonnes réglables.
  Chaque widget a sa propre largeur, calculée depuis le pas Jeedom (voir le tableau).
- **Tableau** : Jeedom place chaque commande dans une case (lignes × colonnes choisies dans la configuration de la tuile).
  La largeur vient alors des cases, pas de ce fichier.

Largeurs en disposition par défaut (pas de 84 px, valeurs par défaut) :

| Widgets | Largeur | Défaut |
|---|---|---|
| LINE, LIST, MSG, SELECT | au plus `(--step-width − --margin-LR) × --nbStep` | 328 px |
| TILE, TILE ACTION, DUAL ACTION | moitié d'une LINE : `((--step-width − --margin-LR) × --nbStep) / 2 − --margin-LR`, au moins `--step-width` | 162 px |

Plus une marge de `--margin-LR` (2 px) de chaque côté. Deux LINE tiennent côte à côte si la tuile fait
au moins 2 × 332 px ; sinon une par ligne. L'espace qui reste est réparti de part et d'autre (centrage).

`--nbStep` vaut 4, puis 3 sous 1024 px, 2 sous 768 px (les TILE prennent alors toute la ligne)
et 1 sous 480 px (largeur de la fenêtre).

Ces variables sont définies sur chaque widget (`.cmd-widget.widget-iso`), pas sur le conteneur :
c'est là qu'il faut les changer.

> ⚠️ À ne pas changer : la largeur d'une TILE doit rester la moitié de celle d'une LINE (marges comprises),
> et le conteneur reste centré (`justify-content: center`). Sinon les bords des lignes ne tombent plus
> au même endroit.

### Des widgets plus larges sur grand écran

```css
/* custom.iso.css */
@media (min-width: 1025px) {
    .cmd-widget.widget-iso {
        --nbStep: 5;   /* LINE de 410 px, TILE de 203 px */
    }
}
```

Gardez le `@media` : sans lui, la règle remplace aussi les valeurs des petits écrans.
Une LINE plus large peut ne plus tenir deux fois sur une ligne : à 410 px, il faut une tuile d'au moins 828 px.

### Un widget par ligne (layout « liste »)

```css
.eqLogic-widget.hasIsocmds .widget-isoLine,
.eqLogic-widget.hasIsocmds .widget-isoList,
.eqLogic-widget.hasIsocmds .widget-isoMsg,
.eqLogic-widget.hasIsocmds .widget-isoSelect {
    max-width: 100% !important;   /* la LINE prend toute la largeur de la tuile */
}
```

### Espacement entre widgets

```css
.cmd-widget.widget-iso {
    --margin-LR: 6px;   /* marge gauche et droite ; réduit aussi la largeur (LINE de 312 px) */
}
```

### Retour à la ligne forcé

Le paramètre Jeedom `forceReturnLineBefore` / `forceReturnLineAfter` d'une commande ajoute un saut de ligne
avant ou après son widget. C'est le moyen de mettre une LINE seule sur sa ligne sans toucher au CSS.
À régler à la main, commande par commande : aucun plugin ne doit l'activer sur un widget iso, sinon tous
les widgets s'empilent sur une seule colonne.

### Disposition en grille, sans vide sous les widgets courts (option)

Quand deux widgets de hauteurs différentes partagent une ligne (dialogue à côté d'une liste, par exemple),
la ligne prend la hauteur du plus haut et laisse un vide sous l'autre. L'option grille place chaque widget
dans la colonne la plus courte, dans l'ordre des commandes : le vide disparaît. Elle est désactivée par défaut.

```css
/* Un équipement (son id est dans l'URL de sa page de configuration) */
.eqLogic-widget[data-eqlogic_id="2501"] { --iso-masonry: 1; }

/* Ou tous les équipements iso */
.eqLogic-widget { --iso-masonry: 1; }
```

- Ne s'applique qu'au-dessus de 768 px de large, et seulement si la tuile est assez large pour deux LINE côte à côte ;
  sinon (tuile étroite, mobile) la disposition habituelle reste en place. Si la tuile est élargie ensuite, la grille revient.
- Jamais en disposition « tableau » de Jeedom.
- Chaque widget prend une hauteur multiple du pas des tuiles Jeedom (Réglages > Système > Configuration, onglet Interface, section « Tuiles », « Pas » : Hauteur,
  30 px sur jee89), marges comprises : une LINE = 1 pas, un widget de 47 px = 2 pas, etc.
  Les hauts des widgets tombent donc sur la même trame dans les deux colonnes.
- TILE = une colonne (moitié de LINE), LINE/LIST/MSG = deux colonnes ; les bords restent alignés. Les retours à la ligne
  forcés (`forceReturnLine`) sont respectés.
- L'ordre de lecture reste celui des commandes, mais en zigzag : un widget peut passer à gauche ou à droite selon les hauteurs,
  et changer de côté si une valeur change de hauteur (liste qui s'allonge).
- La place gagnée reste en bas de la tuile : réduire la hauteur de la tuile (mode édition du dashboard) pour la récupérer.

---

## 2. Apparence générale des widgets

### Couleur de fond et bordures

```css
/* Fond de tous les widgets ISO : !important obligatoire (fond et arrondi le sont dans cmd.iso.css) */
.cmd-widget.widget-iso {
    background-color: #1e1e2e !important;
    border-radius: 10px !important;
    border: 1px solid rgba(255, 255, 255, 0.08);
}
```

### Couleur du texte

```css
/* La valeur d'une LINE est en !important dans cmd.iso.css */
.cmd-widget.widget-iso .cmdName,
.cmd-widget.widget-iso .value {
    color: #cdd6f4 !important;
}
```

---

## 3. Widgets LINE (`iso_line`, `iso_btn`, `iso_switch`, etc.)

Les widgets LINE font 328 px de large au plus (voir section 1) et 24 px de haut.

```css
/* Augmenter la hauteur des lignes */
.cmd-widget.widget-isoLine {
    height: 32px;
}

/* Fond spécifique pour les lignes */
.cmd-widget.widget-isoLine {
    background: rgba(255, 255, 255, 0.04);
    border-radius: 6px;
    padding: 0 8px;
}

/* Nom en italique */
.cmd-widget.widget-isoLine .cmdName {
    font-style: italic;
    opacity: 0.7;
}

/* Valeur en gras */
.cmd-widget.widget-isoLine .value {
    font-weight: bold;
    font-size: 1rem;
}
```

---

## 4. Widgets TILE (`iso_tile`, `iso_tile_round`, etc.)

Les widgets TILE font la moitié d'une LINE en largeur (162 px au plus) et un pas Jeedom en hauteur (84 px).

```css
/* Tuile d'action à l'état « allumé » (iso_tile_action, iso_tile_dual_action) */
.widget-isoTileAction.tile-on .widget-isoTile-container,
.widget-isoTileDualAction.tile-on .widget-isoTile-container {
    background-color: #313244;
    border: 1px solid #89b4fa;
}

/* Valeur principale plus grande */
.cmd-widget.widget-isoTile .value.master {
    font-size: 2rem;
}

/* Nom sous la tuile */
.cmd-widget.widget-isoTile .cmdName {
    font-size: 0.7rem;
    opacity: 0.8;
}
```

---

## 5. Widgets Dialogue (`iso_msg_dialogue`, `iso_ai_dialogue`)

Les widgets dialogue (`.widget-isoMsg.isoDialog`) ont la largeur d'une LINE. Ils se composent d'un en-tête
(`.iso-head`), d'une zone de messages (`.iso-chat`) et d'une zone de saisie (`.iso-composer`).

```css
/* Hauteur de la zone de messages, en pas Jeedom (2 par défaut, 4 sous 768 px) */
.widget-isoMsg.isoDialog {
    --dlg-chat-steps: 6;
}

/* Arrondi des bulles */
.widget-isoMsg.isoDialog {
    --dlg-radius: 12px;
}

/* Bulles envoyées */
.widget-isoMsg.isoDialog .askt-dialog__message--request {
    background: #313244;
}

/* Bulles reçues */
.widget-isoMsg.isoDialog .askt-dialog__message--response {
    background: #1e1e2e;
}
```

---

## 6. Niveaux d'alerte

Les classes `.warning` et `.danger` sont ajoutées automatiquement sur `.value`  
quand le seuil d'alerte Jeedom est atteint.

```css
/* Alerte warning */
.cmd-widget.widget-iso .value.warning {
    color: #f9e2af;
    background: rgba(249, 226, 175, 0.1);
    border-radius: 4px;
    padding: 0 4px;
}

/* Alerte danger */
.cmd-widget.widget-iso .value.danger {
    color: #f38ba8;
    background: rgba(243, 139, 168, 0.1);
    border-radius: 4px;
    padding: 0 4px;
}
```

---

## 7. Responsive (adaptation mobile)

La feuille principale réduit déjà `--nbStep` : 3 sous 1024 px, 2 sous 768 px (TILE sur toute la ligne), 1 sous 480 px.  
Vous pouvez affiner :

```css
@media (max-width: 480px) {
    .cmd-widget.widget-iso {
        font-size: 0.8rem;
    }
    .cmd-widget.widget-isoTile {
        height: 80px;
    }
}
```

---

## 8. Variables disponibles sur `:root`

Injectées automatiquement par `iso.assets.js` depuis la configuration Jeedom.

| Variable | Source Jeedom | Défaut |
|---|---|---|
| `--widget-step-width` | Administration → Interface → Tuiles → Largeur du pas | `84px` |
| `--widget-step-height` | Administration → Interface → Tuiles → Hauteur du pas | `20px` |
| `--widget-margin` | Administration → Interface → Tuiles → Marge | `4px` |

```css
/* Exemple : taille d'icône proportionnelle au pas Jeedom */
.cmd-widget.widget-isoTile .master {
    font-size: calc(var(--widget-step-width) * 0.3);
}
```

---

## 9. Template de départ

Copiez ce bloc dans `iso_src/custom.iso.css` et décommentez ce dont vous avez besoin :

```css
/* =============================================================
   custom.iso.css — Personnalisation widgets ISO (Limad44)
   Chargé après cmd.iso.css — les règles ici ont priorité.
   ============================================================= */

/* --- Disposition (voir section 1) --------------------------- */
/* @media (min-width: 1025px) { .cmd-widget.widget-iso { --nbStep: 5; } } */
/* .cmd-widget.widget-iso { --margin-LR: 6px; } */

/* --- Apparence générale ------------------------------------ */
/* .cmd-widget.widget-iso { } */

/* --- Widgets LINE ------------------------------------------ */
/* .cmd-widget.widget-isoLine { } */
/* .cmd-widget.widget-isoLine .cmdName { } */
/* .cmd-widget.widget-isoLine .value { } */

/* --- Widgets TILE ------------------------------------------ */
/* .cmd-widget.widget-isoTile { } */
/* .widget-isoTileAction.tile-on .widget-isoTile-container { } */

/* --- Alertes ----------------------------------------------- */
/* .cmd-widget.widget-iso .value.warning { } */
/* .cmd-widget.widget-iso .value.danger { } */

/* --- Responsive -------------------------------------------- */
/* @media (max-width: 480px) { } */
```
