# Personnalisation des widgets ISO — `custom.iso.css`

Ce fichier est **le seul endroit recommandé** pour personnaliser l'apparence des widgets ISO.  
Il est chargé automatiquement après `cmd.iso.css` (la feuille principale) et ses règles prennent donc la priorité.

> ⚠️ Ne jamais modifier `cmd.iso.css` directement — vos changements seraient écrasés lors d'une mise à jour.

---

## 1. Système de grille (disposition des colonnes)

Les widgets ISO s'organisent en grille automatique à l'intérieur de chaque équipement (`eqLogic`).  
Deux variables CSS contrôlent le comportement des colonnes :

| Variable | Rôle | Défaut |
|---|---|---|
| `--iso-col-width` | Largeur minimale d'une colonne (en dessous, pas de nouvelle colonne) | `2 × --widget-step-width` |
| `--iso-col-max`   | Largeur maximale d'une colonne (les widgets s'étirent jusqu'à cette valeur) | `4 × --widget-step-width` |

`--widget-step-width` est injecté automatiquement depuis la configuration Jeedom  
(Administration → Interface → Tuiles → Largeur du pas). Valeur par défaut : **84 px**.

### Modifier la grille globalement

```css
/* custom.iso.css */

.eqLogic-widget.hasIsocmds .cmds-iso {
    --iso-col-width: 200px;   /* colonne mini 200px → 2 colonnes à partir de 400px */
    --iso-col-max:   400px;   /* colonne maxi 400px */
    gap: 6px;                 /* espacement entre widgets */
}
```

### Forcer une colonne unique (layout "liste")

```css
.eqLogic-widget.hasIsocmds .cmds-iso {
    grid-template-columns: 1fr !important;
}
```

### Forcer exactement 2 colonnes

```css
.eqLogic-widget.hasIsocmds .cmds-iso {
    grid-template-columns: repeat(2, 1fr) !important;
}
```

---

## 2. Apparence générale des widgets

### Couleur de fond et bordures

```css
/* Fond de tous les widgets ISO */
.cmd-widget.widget-iso {
    background-color: #1e1e2e;
    border-radius: 10px;
    border: 1px solid rgba(255, 255, 255, 0.08);
}
```

### Couleur du texte

```css
.cmd-widget.widget-iso .cmdName,
.cmd-widget.widget-iso .value {
    color: #cdd6f4;
}
```

---

## 3. Widgets LINE (`iso_line`, `iso_btn`, `iso_switch`, etc.)

Les widgets LINE occupent toute la largeur de leur colonne et ont une hauteur fixe de 24 px.

```css
/* Augmenter la hauteur des lignes */
.cmd-widget.widget-isoLine {
    height: 32px;
}

/* Fond spécifique pour les lignes */
.cmd-widget.widget-isoLine {
    background: rgba(255, 255, 255, 0.04);
    border-radius: 6px;
    padding: 0 8px;
}

/* Nom en italique */
.cmd-widget.widget-isoLine .cmdName {
    font-style: italic;
    opacity: 0.7;
}

/* Valeur en gras */
.cmd-widget.widget-isoLine .value {
    font-weight: bold;
    font-size: 1rem;
}
```

---

## 4. Widgets TILE (`iso_tile`, `iso_tile_round`, etc.)

Les widgets TILE sont carrés (hauteur = largeur de colonne).

```css
/* Fond "actif" pour les tuiles booléennes */
.cmd-widget.widget-isoTile.tile-on {
    background-color: #313244;
    border: 1px solid #89b4fa;
}

/* Icône plus grande */
.cmd-widget.widget-isoTile .master {
    font-size: 2rem;
}

/* Nom sous la tuile */
.cmd-widget.widget-isoTile .cmdName {
    font-size: 0.7rem;
    opacity: 0.8;
}
```

---

## 5. Widgets Dialogue (`iso_msg_dialogue`, `iso_ai_dialogue`)

Les widgets dialogue occupent toute la largeur de la grille (`grid-column: 1 / -1`).

```css
/* Fond du dialogue */
.cmd-widget.widget-isoMsg.isoDialog {
    background-color: #181825;
    border: 1px solid #45475a;
    border-radius: 12px;
    padding: 8px;
}

/* Zone de messages */
.cmd-widget.widget-isoMsg.isoDialog .iso-history {
    max-height: 300px;   /* hauteur max de l'historique */
    font-size: 0.85rem;
}

/* Bulles "utilisateur" */
.cmd-widget.widget-isoMsg.isoDialog .iso-bubble-user {
    background: #313244;
    border-radius: 12px 12px 2px 12px;
}

/* Bulles "assistant" */
.cmd-widget.widget-isoMsg.isoDialog .iso-bubble-bot {
    background: #1e1e2e;
    border-radius: 12px 12px 12px 2px;
}
```

---

## 6. Niveaux d'alerte

Les classes `.warning` et `.danger` sont ajoutées automatiquement sur `.value`  
quand le seuil d'alerte Jeedom est atteint.

```css
/* Alerte warning */
.cmd-widget.widget-iso .value.warning {
    color: #f9e2af;
    background: rgba(249, 226, 175, 0.1);
    border-radius: 4px;
    padding: 0 4px;
}

/* Alerte danger */
.cmd-widget.widget-iso .value.danger {
    color: #f38ba8;
    background: rgba(243, 139, 168, 0.1);
    border-radius: 4px;
    padding: 0 4px;
}
```

---

## 7. Responsive (adaptation mobile)

La feuille principale applique déjà une colonne unique sous 768 px.  
Vous pouvez affiner :

```css
@media (max-width: 480px) {
    .cmd-widget.widget-iso {
        font-size: 0.8rem;
    }
    .cmd-widget.widget-isoTile {
        height: 80px;
    }
}
```

---

## 8. Variables disponibles sur `:root`

Injectées automatiquement par `iso.assets.js` depuis la configuration Jeedom.

| Variable | Source Jeedom | Défaut |
|---|---|---|
| `--widget-step-width` | Administration → Interface → Tuiles → Largeur du pas | `84px` |
| `--widget-step-height` | Administration → Interface → Tuiles → Hauteur du pas | `20px` |
| `--widget-margin` | Administration → Interface → Tuiles → Marge | `4px` |

```css
/* Exemple : taille d'icône proportionnelle au pas Jeedom */
.cmd-widget.widget-isoTile .master {
    font-size: calc(var(--widget-step-width) * 0.3);
}
```

---

## 9. Template de départ

Copiez ce bloc dans `iso_src/custom.iso.css` et décommentez ce dont vous avez besoin :

```css
/* =============================================================
   custom.iso.css — Personnalisation widgets ISO (Limad44)
   Chargé après cmd.iso.css — les règles ici ont priorité.
   ============================================================= */

/* --- Grille ------------------------------------------------- */
.eqLogic-widget.hasIsocmds .cmds-iso {
    /* --iso-col-width: 200px; */
    /* --iso-col-max:   380px; */
    /* gap: 6px; */
}

/* --- Apparence générale ------------------------------------ */
/* .cmd-widget.widget-iso { } */

/* --- Widgets LINE ------------------------------------------ */
/* .cmd-widget.widget-isoLine { } */
/* .cmd-widget.widget-isoLine .cmdName { } */
/* .cmd-widget.widget-isoLine .value { } */

/* --- Widgets TILE ------------------------------------------ */
/* .cmd-widget.widget-isoTile { } */
/* .cmd-widget.widget-isoTile.tile-on { } */

/* --- Alertes ----------------------------------------------- */
/* .cmd-widget.widget-iso .value.warning { } */
/* .cmd-widget.widget-iso .value.danger { } */

/* --- Responsive -------------------------------------------- */
/* @media (max-width: 480px) { } */
```
