/* Spanish locals for fltpickr */
import { CustomLocale } from "../types/locale";
import { fltpickrFn } from "../types/instance";

const fp =
  typeof window !== "undefined" && window.fltpickr !== undefined
    ? window.fltpickr
    : ({
        l10ns: {},
      } as fltpickrFn);

export const Spanish: CustomLocale = {
  weekdays: {
    shorthand: ["Dom", "Lun", "Mar", "Mié", "Jue", "Vie", "Sáb"],
    longhand: [
      "Domingo",
      "Lunes",
      "Martes",
      "Miércoles",
      "Jueves",
      "Viernes",
      "Sábado",
    ],
  },

  months: {
    shorthand: [
      "Ene",
      "Feb",
      "Mar",
      "Abr",
      "May",
      "Jun",
      "Jul",
      "Ago",
      "Sep",
      "Oct",
      "Nov",
      "Dic",
    ],
    longhand: [
      "Enero",
      "Febrero",
      "Marzo",
      "Abril",
      "Mayo",
      "Junio",
      "Julio",
      "Agosto",
      "Septiembre",
      "Octubre",
      "Noviembre",
      "Diciembre",
    ],
  },

  ordinal: () => {
    return "º";
  },

  firstDayOfWeek: 1,
  rangeSeparator: " a ",
  time_24hr: true,
};

fp.l10ns.es = Spanish;

export default fp.l10ns;
