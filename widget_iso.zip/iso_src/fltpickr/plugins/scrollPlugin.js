
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
29
30
31
32
33
34
35
36
37
38
39
40
41
42
43
44
45
46
47
48
49
50
51
52
53
54
55
56
57
58
59
60
61
62
63
64
65
66
67
68
69
70
71
72
73
74
75
76
77
78
79
80
81
82
83
84
85
86
87
88
89
90
91
92
93
(function (global, factory) {
  typeof exports === 'object' && typeof module !== 'undefined' ? module.exports = factory() :
  typeof define === 'function' && define.amd ? define(factory) :
  (global = typeof globalThis !== 'undefined' ? globalThis : global || self, global.scrollPlugin = factory());
}(this, (function () { 'use strict';

  function getEventTarget(event) {
      try {
          if (typeof event.composedPath === "function") {
              var path = event.composedPath();
              return path[0];
          }
          return event.target;
      }
      catch (error) {
          return event.target;
      }
  }

  if (typeof window.CustomEvent !== "function") {
      var CustomEvent = function (typeArg, eventInitDict) {
          eventInitDict = eventInitDict || {
              bubbles: false,
              cancelable: false,
              detail: undefined,
          };
          var evt = document.createEvent("CustomEvent");
          evt.initCustomEvent(typeArg, eventInitDict.bubbles, eventInitDict.cancelable, eventInitDict.detail);
          return evt;
      };
      CustomEvent.prototype = window.Event.prototype;
      window.CustomEvent = CustomEvent;
  }
  function delta(e) {
      return Math.max(-1, Math.min(1, e.wheelDelta || -e.deltaY));
  }
  var scroll = function (e) {
      e.preventDefault();
      var ev = new CustomEvent("increment", {
          bubbles: true,
      });
      ev.delta = delta(e);
      getEventTarget(e).dispatchEvent(ev);
  };
  function scrollMonth(fp) {
      return function (e) {
          e.preventDefault();
          var mDelta = delta(e);
          fp.changeMonth(mDelta);
      };
  }
  function scrollPlugin() {
      return function (fp) {
          var monthScroller = scrollMonth(fp);
          return {
              onReady: function () {
                  if (fp.timeContainer) {
                      fp.timeContainer.addEventListener("wheel", scroll);
                  }
                  if (fp.yearElements) {
                      fp.yearElements.forEach(function (yearElem) {
                          return yearElem.addEventListener("wheel", scroll);
                      });
                  }
                  if (fp.monthElements) {
                      fp.monthElements.forEach(function (monthElem) {
                          return monthElem.addEventListener("wheel", monthScroller);
                      });
                  }
                  fp.loadedPlugins.push("scroll");
              },
              onDestroy: function () {
                  if (fp.timeContainer) {
                      fp.timeContainer.removeEventListener("wheel", scroll);
                  }
                  if (fp.yearElements) {
                      fp.yearElements.forEach(function (yearElem) {
                          return yearElem.removeEventListener("wheel", scroll);
                      });
                  }
                  if (fp.monthElements) {
                      fp.monthElements.forEach(function (monthElem) {
                          return monthElem.removeEventListener("wheel", monthScroller);
                      });
                  }
              },
          };
      };
  }

  return scrollPlugin;

})));