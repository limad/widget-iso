(function (window, document) {
    'use strict';
    if (window.isoWidgets) return;

    // Load iso.assets.js automatically if not present
    if (typeof window.isoEnsureAssets !== 'function') {
        var script = document.getElementById('iso_assets_js');
        if (!script) {
            script = document.createElement('script');
            script.id = 'iso_assets_js';
            script.src = 'data/customTemplates/dashboard/iso_src/iso.assets.js?v=20260621f';
            script.onload = function () { if (typeof window.isoEnsureAssets === 'function') window.isoEnsureAssets(); };
            document.head.appendChild(script);
        }
    } else {
        window.isoEnsureAssets();
    }

    function roundTemp(value) {
        return Math.round(value * 10) / 10;
    }

    window.isoWidgets = {
        initTile: function (uid, config) {
            var cmdEl = document.querySelector('.cmd[data-cmd_uid="' + uid + '"]');
            if (!cmdEl) return;

            var intNumTemp = cmdEl.querySelector('.intNumTemp');
            var decNumTemp = cmdEl.querySelector('.decNumTemp');
            var uniteTemp = cmdEl.querySelector('.uniteTemp');
            var titleEl = cmdEl.querySelector('.title');
            var containerEl = cmdEl.querySelector('.widget-isoTile-container');
            var valueEl = cmdEl.querySelector('.value');

            // Apply CSS Variables
            if (config.ist_color && config.ist_color !== '#ist_color#' && containerEl) containerEl.style.setProperty('--ist-color', config.ist_color);
            if (config.ist_bgcolor && config.ist_bgcolor !== '#ist_bgcolor#' && containerEl) containerEl.style.setProperty('--ist-bgcolor', config.ist_bgcolor);
            if (config.ist_thickness && config.ist_thickness !== '#ist_thickness#' && containerEl) containerEl.style.setProperty('--ist-thickness', config.ist_thickness + 'px');
            if (config.scale && config.scale !== '#scale#' && containerEl) containerEl.style.setProperty('--scale', config.scale);

            if (typeof jeedom === 'undefined' || !jeedom.cmd) return;

            delete jeedom.cmd.update[config.id];
            jeedom.cmd.addUpdateFunction(config.id, function (_options) {
                if (typeof is_object === 'function' && !is_object(cmdEl)) return;
                var eqLogic = cmdEl.closest('.eqLogic');
                if (eqLogic) {
                    var eqCmds = eqLogic.querySelector('.cmds');
                    if (eqCmds) eqCmds.classList.add('cmds-iso');
                    eqLogic.classList.add('hasIsocmds');
                }

                if (titleEl && titleEl.classList.contains('hidden') && containerEl) {
                    containerEl.classList.add('noTitle');
                    var inlineName = cmdEl.querySelector('.tile-inline-name');
                    if (inlineName) {
                        inlineName.textContent = config.name;
                        inlineName.style.display = '';
                    }
                }

                cmdEl.setAttribute('title', config.name + '\n{{Date de valeur}} : ' + _options.valueDate + '\n{{Date de collecte}} : ' + _options.collectDate);

                var parsed = parseFloat(_options.display_value);
                var n = isNaN(parsed) ? '' : parsed.toFixed(1);
                var _int = isNaN(parsed) ? '--' : n.split('.')[0];
                var _dec = isNaN(parsed) ? '' : (n.split('.')[1] || '');
                if (_dec == '0') _dec = '';
                var length = (_int + _dec + (_options.unit || '')).length;

                if (intNumTemp) intNumTemp.textContent = _int;
                if (decNumTemp) decNumTemp.textContent = _dec;
                if (uniteTemp) {
                    if (length > 8) uniteTemp.classList.add('atline');
                    uniteTemp.textContent = _options.unit || '';
                }

                cmdEl.classList.add('hasMaster');
                if (valueEl) {
                    valueEl.classList.remove('warning', 'danger');
                    if (_options.alertLevel === 'warning') valueEl.classList.add('warning');
                    else if (_options.alertLevel === 'danger') valueEl.classList.add('danger');
                }
                
                var cmdStats = cmdEl.querySelector('.cmdStats');
                if (cmdStats && !cmdStats.classList.contains('hidden') && valueEl) {
                    valueEl.classList.add('hasStats', 'hasSlave');
                }
            });

            jeedom.cmd.refreshValue([{ 
                cmd_id: config.id, 
                display_value: config.value, 
                valueDate: config.valueDate, 
                collectDate: config.collectDate, 
                alertLevel: config.alertLevel, 
                unit: config.unite 
            }]);
        },

        initThermostat: function (uid, config) {
            var cmdEl = document.querySelector('.cmd[data-cmd_uid="' + uid + '"]');
            if (!cmdEl) return;

            var CONFIG = {
                MIN_TEMP: 7,
                MAX_TEMP: 30,
                STEP: 0.5,
                LG_CLICK_INTERVAL: 200,
                WAIT_INTERVAL: 900
            };

            var consigne = parseFloat(config.state) || 20;
            var temperature = 17.8;
            var intervalId = null;
            var timeoutId = null;

            var cons_intNum = cmdEl.querySelector('.cons .intNum');
            var cons_decNum = cmdEl.querySelector('.cons .decNum');
            var temp_intNum = cmdEl.querySelector('.temp .intNum');
            var temp_decNum = cmdEl.querySelector('.temp .decNum');
            var btPlus = cmdEl.querySelector('.bt_plus');
            var btMinus = cmdEl.querySelector('.bt_minus');
            var inVal = cmdEl.querySelector('.in_value');

            if (config.width && parseFloat(config.width) >= 70 && inVal) {
                inVal.style.width = config.width + 'px';
            }

            function renderCons() {
                var intPart = Math.floor(consigne);
                var decPart = Math.round((consigne - intPart) * 10);
                if (cons_intNum) cons_intNum.textContent = intPart;
                if (cons_decNum) cons_decNum.textContent = decPart;
            }

            function renderTemp() {
                var intPart = Math.floor(temperature);
                var decPart = Math.round((temperature - intPart) * 10);
                if (temp_intNum) temp_intNum.textContent = intPart;
                if (temp_decNum) temp_decNum.textContent = decPart;
            }

            function setSetpoint() {
                if (typeof jeedom !== 'undefined' && jeedom.cmd) {
                    jeedom.cmd.execute({ id: config.id, value: { slider: consigne } });
                }
            }

            function scheduleSetpoint() {
                clearTimeout(timeoutId);
                timeoutId = setTimeout(setSetpoint, CONFIG.WAIT_INTERVAL);
            }

            function updateConsigne(delta) {
                var newValue = consigne + delta;
                if (newValue >= CONFIG.MIN_TEMP && newValue <= CONFIG.MAX_TEMP) {
                    consigne = roundTemp(newValue);
                    renderCons();
                    scheduleSetpoint();
                }
            }

            function startChanging(delta) {
                updateConsigne(delta);
                intervalId = setInterval(function () { updateConsigne(delta); }, CONFIG.LG_CLICK_INTERVAL);
            }

            function stopChanging() {
                if (intervalId) {
                    clearInterval(intervalId);
                    intervalId = null;
                }
            }

            function addButtonListeners(btn, delta) {
                if (!btn) return;
                btn.addEventListener('mousedown', function () { startChanging(delta); });
                btn.addEventListener('mouseup', stopChanging);
                btn.addEventListener('mouseleave', stopChanging);
                btn.addEventListener('touchstart', function (e) { e.preventDefault(); startChanging(delta); }, {passive: false});
                btn.addEventListener('touchend', stopChanging);
                btn.addEventListener('touchcancel', stopChanging);
            }

            addButtonListeners(btPlus, CONFIG.STEP);
            addButtonListeners(btMinus, -CONFIG.STEP);

            // Cache for DOM queries to avoid layout thrashing on updates
            var eqLogic = cmdEl.closest('.eqLogic');
            var temperatureCmdEl = null;
            var timeCmdEl = cmdEl.querySelector('.timeCmd');
            var searchName = config.cmdiTemperature !== '#cmdiTemperature#' && config.cmdiTemperature !== '' ? config.cmdiTemperature : 'temperature';

            if (eqLogic) {
                // Find temperature cmd only once
                var elements = eqLogic.querySelectorAll('.cmd[data-type="info"] .cmdName');
                for (var i = 0; i < elements.length; i++) {
                    if (elements[i].textContent.trim() === searchName && elements[i].closest('.cmd').querySelector('.value')) {
                        temperatureCmdEl = elements[i].closest('.cmd');
                        break;
                    }
                }
                
                // Hide target command once
                var targetCmdi = eqLogic.querySelector('.cmd[data-cmd_id="' + config.value_id + '"]');
                if (targetCmdi) targetCmdi.style.display = 'none';
                else {
                    var ttemp = cmdEl.querySelector('.thermo .temp');
                    if (ttemp) ttemp.style.display = 'none';
                }
            }

            if (typeof jeedom === 'undefined' || !jeedom.cmd) return;

            delete jeedom.cmd.update[config.id];
            jeedom.cmd.addUpdateFunction(config.id, function (_options) {
                if (typeof is_object === 'function' && !is_object(cmdEl)) return;
                if (eqLogic) {
                    var eqCmds = eqLogic.querySelector('.cmds');
                    if (eqCmds) eqCmds.classList.add('cmds-iso');
                    eqLogic.classList.add('hasIsocmds');
                }

                if (config.time === 'duration' || config.time === 'date') {
                    jeedom.cmd.displayDuration(_options.valueDate, timeCmdEl, config.time);
                }

                if (_options.value !== undefined) {
                    consigne = parseFloat(_options.value);
                    renderCons();
                }

                if (temperatureCmdEl) {
                    var valEl = temperatureCmdEl.querySelector('.value');
                    if (valEl) {
                        var targetTemp = valEl.textContent.split(' ')[0].replace(/\s+/g, '');
                        if (!isNaN(parseFloat(targetTemp))) temperature = parseFloat(targetTemp);
                    }
                    temperatureCmdEl.style.display = 'none';
                }
                renderTemp();
            });

            jeedom.cmd.refreshValue([{
                cmd_id: config.id,
                value: config.state,
                display_value: config.state,
                valueDate: config.valueDate,
                collectDate: config.collectDate,
                alertLevel: config.alertLevel,
                unit: ''
            }]);
        }
    };
})(window, document);
